# IconFix for macOS

IconFix is a tiny macOS app wrapper that clears the macOS icon services cache and restarts Dock/Finder.

## Install

1. Download and unzip `IconFix-macOS-App.zip`.
2. Drag `IconFix.app` into your Applications folder.
3. Right-click `IconFix.app` and choose **Open** the first time.

## What it runs

```bash
sudo rm -rfv /Library/Caches/com.apple.iconservices.store; killall Dock; killall Finder
```

## Notes

- macOS will ask for an administrator password.
- Finder and Dock will restart during the process.
- This app is unsigned, so macOS Gatekeeper may require right-click → Open on first launch.
